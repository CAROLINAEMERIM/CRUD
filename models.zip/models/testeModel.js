const db = require('../config/db');

const Teste = {
    create: (teste, callback) => {
        const query = 'INSERT INTO teste (nome, descricao) VALUES (?, ?)';
        db.query(query, [teste.nome, teste.descricao], (err, results) => {
            if (err) return callback(err);
            callback(null, results.insertId);
        });
    },

    findById: (id, callback) => {
        const query = 'SELECT * FROM teste WHERE id = ?';
        db.query(query, [id], (err, results) => {
            if (err) return callback(err);
            callback(null, results[0]);
        });
    },

    update: (id, teste, callback) => {
        const query = 'UPDATE teste SET nome = ?, descricao = ? WHERE id = ?';
        db.query(query, [teste.nome, teste.descricao, id], (err, results) => {
            if (err) return callback(err);
            callback(null, results);
        });
    },

    delete: (id, callback) => {
        const query = 'DELETE FROM teste WHERE id = ?';
        db.query(query, [id], (err, results) => {
            if (err) return callback(err);
            callback(null, results);
        });
    },

    getAll: (callback) => {
        const query = 'SELECT * FROM teste';
        db.query(query, (err, results) => {
            if (err) return callback(err);
            callback(null, results);
        });
    },
};

module.exports = Teste;